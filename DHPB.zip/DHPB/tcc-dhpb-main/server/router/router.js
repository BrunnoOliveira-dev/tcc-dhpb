const express = require("express");
const router = express.Router();

const { Pessoa, Escola, Aluno, Professor } = require("../models");


// ============================
// ROTAS PARA PESSOA
// ============================

// Criar nova pessoa
router.post("/pessoas", async (req, res) => {
  try {
    const novaPessoa = await Pessoa.create(req.body);
    res.status(201).json(novaPessoa);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

// Listar pessoas
router.get("/pessoas", async (req, res) => {
  try {
    const pessoas = await Pessoa.findAll();
    res.json(pessoas);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});


// ============================
// ROTAS PARA ESCOLA
// ============================

router.post("/escolas", async (req, res) => {
  try {
    const novaEscola = await Escola.create(req.body);
    res.status(201).json(novaEscola);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

router.get("/escolas", async (req, res) => {
  try {
    const escolas = await Escola.findAll();
    res.json(escolas);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});


// ============================
// ROTAS PARA ALUNO
// ============================

router.post("/alunos", async (req, res) => {
  try {
    const novoAluno = await Aluno.create(req.body);
    res.status(201).json(novoAluno);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

router.get("/alunos", async (req, res) => {
  try {
    const alunos = await Aluno.findAll({ include: [Pessoa, Escola] });
    res.json(alunos);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});


// ============================
// ROTAS PARA PROFESSOR
// ============================

router.post("/professores", async (req, res) => {
  try {
    const novoProfessor = await Professor.create(req.body);
    res.status(201).json(novoProfessor);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

router.get("/professores", async (req, res) => {
  try {
    const professores = await Professor.findAll({ include: [Pessoa] });
    res.json(professores);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

module.exports = router;
