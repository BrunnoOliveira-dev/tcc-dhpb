const { DataTypes } = require("sequelize");
const sequelize = require("../config/config_db");

const Aluno = sequelize.define("Aluno", {
id_aluno: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
},
id_pessoa: {
    type: DataTypes.INTEGER,
    allowNull: false,
},
id_escola: {
    type: DataTypes.INTEGER,
    allowNull: false,
},
matricula: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: true,
},
}, {
tableName: "alunos",
timestamps: true,
createdAt: "created_at",
updatedAt: "updated_at"
});

module.exports = Aluno;
