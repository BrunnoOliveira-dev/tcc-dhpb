const { DataTypes } = require("sequelize");
const sequelize = require("../config/config_db");

const Professor = sequelize.define("Professor", {
id_professor: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
},
idpessoa: {
    type: DataTypes.INTEGER,
    allowNull: false,
},
disciplina: {
    type: DataTypes.STRING(100),
    allowNull: false,
},
}, {
tableName: "professores",
timestamps: true,
createdAt: "created_at",
updatedAt: "updated_at"
});

module.exports = Professor;
