const { Sequelize } = require("sequelize");

const db_name = "railway";
const db_user = "root";
const db_password = "kBZUqKMbHSTcDVdsFzWKrIhXDrhbTPGV";
const db_host = "gondola.proxy.rlwy.net";
const db_dialect = "mysql";
const db_port = 36544;

const sequelize = new Sequelize(db_name, db_user, db_password, {
  host: db_host,
  dialect: db_dialect,
  port: db_port,
});

module.exports = sequelize;
