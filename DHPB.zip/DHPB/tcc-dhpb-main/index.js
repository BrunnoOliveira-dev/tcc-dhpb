const express = require("express");
const app = express();
const port = 3000;

// Importa os modelos e a conexão com o banco
const { sequelize } = require("./server/models");

// Importa as rotas
const router = require("./server/router/router");

// Middleware para ler JSON e arquivos estáticos
app.use(express.json());
app.use(express.static("client/src")); // Corrigido: "clqient" → "client"
app.use("/node_modules", express.static("node_modules"));

// Usa as rotas
app.use(router);

// Testa conexão com o banco e sincroniza tabelas
(async () => {
  try {
    await sequelize.authenticate();
    console.log("✅ Conectado ao banco de dados!");
    await sequelize.sync();
    console.log("📦 Tabelas sincronizadas com sucesso!");
  } catch (error) {
    console.error("❌ Erro ao conectar com o banco:", error);
  }
})();

// Inicia o servidor
app.listen(port, () => {
  console.log(`🚀 Servidor rodando em: http://localhost:${port}`);
});
